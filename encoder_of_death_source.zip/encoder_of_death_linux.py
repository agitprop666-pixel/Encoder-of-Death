from __future__ import annotations

import sys
import subprocess
import json
import os
from pathlib import Path
from typing import Optional
from dataclasses import dataclass

from PyQt6.QtCore import Qt, QThread, pyqtSignal, QSize
from PyQt6.QtGui import QColor, QFont, QPainter, QPixmap, QPalette, QIcon
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QListWidget, QComboBox, QSpinBox,
    QFileDialog, QProgressBar, QTextEdit, QGroupBox, QCheckBox,
    QSplashScreen, QMessageBox, QListWidgetItem, QScrollArea
)

# =============================================================================
# Global Definitions
# =============================================================================
APP_NAME = "Encoder of Death"
ORG_NAME = "Death's Head Software"

# =============================================================================
# Resource Resolution (PyInstaller-safe)
# =============================================================================
def resolve_resource(filename):
    """Resolve path to bundled resource files (images, etc.)"""
    if getattr(sys, "frozen", False):
        # PyInstaller bundle
        if hasattr(sys, '_MEIPASS'):
            # Try _MEIPASS first (temp extraction folder)
            resource_path = os.path.join(sys._MEIPASS, filename)
            if os.path.exists(resource_path):
                return resource_path
        
        # Try relative to executable (for macOS .app bundles)
        base = os.path.dirname(sys.executable)
        resource_path = os.path.join(base, "..", "Resources", filename)
        resource_path = os.path.abspath(resource_path)
        if os.path.exists(resource_path):
            return resource_path
        
        # Try same directory as executable (Windows/Linux)
        resource_path = os.path.join(base, filename)
        if os.path.exists(resource_path):
            return resource_path
    
    # Development mode - check script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    resource_path = os.path.join(script_dir, filename)
    if os.path.exists(resource_path):
        return resource_path
    
    return None


def resolve_ffmpeg():
    """Find FFmpeg executable, checking bundled location first."""
    import shutil
    
    if getattr(sys, "frozen", False):
        # Running as PyInstaller bundle
        ffmpeg_name = 'ffmpeg.exe' if sys.platform == 'win32' else 'ffmpeg'
        
        # Check _MEIPASS first (temp extraction folder for --onefile)
        if hasattr(sys, '_MEIPASS'):
            ffmpeg_path = os.path.join(sys._MEIPASS, ffmpeg_name)
            if os.path.exists(ffmpeg_path):
                return ffmpeg_path
        
        # Check same directory as executable (for --onedir or Windows)
        base = os.path.dirname(sys.executable)
        ffmpeg_path = os.path.join(base, ffmpeg_name)
        if os.path.exists(ffmpeg_path):
            return ffmpeg_path
        
        # Check bundled subdirectory
        ffmpeg_path = os.path.join(base, 'ffmpeg', ffmpeg_name)
        if os.path.exists(ffmpeg_path):
            return ffmpeg_path
    
    # Fall back to system FFmpeg
    return shutil.which("ffmpeg")


FFMPEG_PATH = resolve_ffmpeg()
if not FFMPEG_PATH:
    import warnings
    warnings.warn("FFmpeg not found. Encoding will fail without FFmpeg in PATH.")

# =============================================================================
# Data Classes
# =============================================================================
@dataclass
class EncodingJob:
    input_file: str
    output_file: str
    format: str
    audio_codec: str
    video_codec: Optional[str]
    audio_bitrate: str
    sample_rate: str
    bit_depth: str
    video_bitrate: Optional[str]
    video_width: Optional[int]
    video_height: Optional[int]
    video_fps: Optional[str]
    audio_only: bool

# =============================================================================
# Splash Screen
# =============================================================================
def create_splash():
    """Creates the splash screen with Encoder of Death branding."""
    try:
        splash_path = resolve_resource("splash.png")
        
        if splash_path and os.path.exists(splash_path):
            pixmap = QPixmap(splash_path)
            if not pixmap.isNull():
                if pixmap.width() != 800 or pixmap.height() != 600:
                    pixmap = pixmap.scaled(800, 600, Qt.AspectRatioMode.KeepAspectRatio,
                                          Qt.TransformationMode.SmoothTransformation)
                painter = QPainter(pixmap)
                painter.setPen(QColor(255, 255, 255))
                painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
                text_rect = pixmap.rect()
                text_rect.setTop(40)
                text_rect.setBottom(100)
                painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
                painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
                footer_rect = pixmap.rect()
                footer_rect.setTop(pixmap.height() - 100)
                footer_rect.setBottom(pixmap.height() - 50)
                painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
                painter.end()
                return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
        
        # Fallback: Generate the dark-themed screen with ASCII art skull
        pixmap = QPixmap(800, 600)
        pixmap.fill(QColor(20, 20, 20))
        painter = QPainter(pixmap)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 38, QFont.Weight.Bold))
        text_rect = pixmap.rect()
        text_rect.setTop(40)
        text_rect.setBottom(100)
        painter.drawText(text_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, APP_NAME)
        painter.setFont(QFont("Courier", 14))
        skull_art = [
            "        ___________      ",
            "       /           \\    ",
            "      |  O       O  |   ",
            "      |      ^      |   ",
            "      |   \\_____/   |   ",
            "       \\_         _/    ",
            "         |_______|      ",
        ]
        y_start = 250
        for i, line in enumerate(skull_art):
            painter.drawText(250, y_start + (i * 25), line)
        painter.setPen(QColor(255, 255, 255))
        painter.setFont(QFont("Courier", 14, QFont.Weight.Bold))
        footer_rect = pixmap.rect()
        footer_rect.setTop(pixmap.height() - 50)
        footer_rect.setBottom(pixmap.height())
        painter.drawText(footer_rect, Qt.AlignmentFlag.AlignCenter | Qt.AlignmentFlag.AlignVCenter, ORG_NAME)
        painter.end()
        return QSplashScreen(pixmap, Qt.WindowType.WindowStaysOnTopHint)
    except Exception as e:
        print("Splash error:", e)
        return None

# =============================================================================
# Encoding Thread
# =============================================================================
class EncodingThread(QThread):
    job_started = pyqtSignal(int, int, str, str)  # current file #, total files, filename, ffmpeg_cmd
    job_complete = pyqtSignal(str, bool, str, int)  # output file, success, message, completed count
    all_complete = pyqtSignal()
    
    def __init__(self, jobs: list[EncodingJob]):
        super().__init__()
        self.jobs = jobs
        self.is_cancelled = False
        self.completed_jobs = 0
        self.current_process = None
    
    def run(self):
        for idx, job in enumerate(self.jobs):
            if self.is_cancelled:
                break
            
            filename = Path(job.input_file).name
            # Build the FFmpeg command first to show it in the log
            cmd = self.build_ffmpeg_command(job)
            ffmpeg_cmd = " ".join(cmd)
            self.job_started.emit(idx + 1, len(self.jobs), filename, ffmpeg_cmd)
            success, message = self.execute_ffmpeg(cmd, job.output_file)
            self.completed_jobs += 1
            self.job_complete.emit(job.output_file, success, message, self.completed_jobs)
        
        self.all_complete.emit()
    
    def build_ffmpeg_command(self, job: EncodingJob) -> list[str]:
        """Build the FFmpeg command."""
        ffmpeg = FFMPEG_PATH if FFMPEG_PATH else 'ffmpeg'
        cmd = [ffmpeg, '-i', job.input_file, '-y']
        
        if job.audio_only:
            cmd.extend(['-vn'])
        elif job.video_codec:
            # Don't copy video codec if changing dimensions or framerate
            if job.video_codec == 'copy' and (job.video_width or job.video_height or job.video_fps):
                cmd.extend(['-c:v', 'libx264'])
            else:
                cmd.extend(['-c:v', job.video_codec])
            
            if job.video_codec != 'copy' and job.video_bitrate:
                cmd.extend(['-b:v', job.video_bitrate])
            if job.video_width and job.video_height:
                cmd.extend(['-s', f'{job.video_width}x{job.video_height}'])
            if job.video_fps:
                cmd.extend(['-r', job.video_fps])
            
            # Add specific settings for VP9 encoding
            if job.video_codec == 'libvpx-vp9':
                cmd.extend(['-deadline', 'realtime', '-cpu-used', '5', '-row-mt', '1'])
        
        # Audio codec and settings
        codec_name = job.audio_codec
        
        # Map bit depth to appropriate codec for lossless formats
        if job.format in ['wav', 'aiff']:
            if job.bit_depth == '8':
                codec_name = 'pcm_u8'
            elif job.bit_depth == '16':
                codec_name = 'pcm_s16le' if job.format == 'wav' else 'pcm_s16be'
            elif job.bit_depth == '24':
                codec_name = 'pcm_s24le' if job.format == 'wav' else 'pcm_s24be'
            elif job.bit_depth == '32':
                codec_name = 'pcm_s32le' if job.format == 'wav' else 'pcm_s32be'
            elif job.bit_depth == '32f':
                codec_name = 'pcm_f32le' if job.format == 'wav' else 'pcm_f32be'
        
        # Format-specific codec selection
        if job.format == 'webm' and codec_name not in ['libvorbis', 'libopus']:
            codec_name = 'libvorbis'
        elif job.format in ['mpeg', 'mpg'] and codec_name not in ['mp2', 'mp3']:
            codec_name = 'mp2'
        elif job.format == 'mp4' and codec_name == 'libvorbis':
            codec_name = 'aac'
        elif job.format == 'avi' and codec_name in ['libopus']:
            codec_name = 'mp3'
        
        cmd.extend(['-c:a', codec_name])
        
        # Only add audio bitrate for compressed formats
        compressed_codecs = ['aac', 'mp3', 'mp2', 'libvorbis', 'libopus']
        if codec_name in compressed_codecs or job.audio_codec in compressed_codecs:
            cmd.extend(['-b:a', job.audio_bitrate])
        
        cmd.extend(['-ar', job.sample_rate])
        
        # Format-specific settings
        if job.format in ['mp4', 'm4v', 'mov']:
            # MP4/MOV format settings for web compatibility
            if job.video_codec and job.video_codec != 'copy':
                cmd.extend(['-pix_fmt', 'yuv420p'])
            # Enable fast start for web streaming (moves moov atom to beginning)
            if job.format in ['mp4', 'm4v']:
                cmd.extend(['-movflags', '+faststart'])
            # Use optimized settings for web playback
            if not job.audio_only:
                for i, arg in enumerate(cmd):
                    if arg == '-c:v' and i + 1 < len(cmd):
                        # If using libx264, ensure baseline profile for compatibility
                        if cmd[i + 1] == 'libx264':
                            cmd.extend(['-preset', 'faster', '-profile:v', 'main', '-level', '4.0'])
                            break
        
        elif job.format == 'webm':
            # WebM format settings for web compatibility
            if job.video_codec == 'libvpx-vp9':
                # Ensure proper color space for web playback
                cmd.extend(['-pix_fmt', 'yuv420p'])
        
        if job.format in ['mpeg', 'mpg']:
            # MPEG-1/2 specific settings
            cmd.extend(['-f', 'mpeg'])
            if job.video_codec and job.video_codec != 'copy':
                # Use mpeg2video for MPEG format
                for i, arg in enumerate(cmd):
                    if arg == '-c:v' and i + 1 < len(cmd):
                        if cmd[i + 1] not in ['copy', 'mpeg2video', 'mpeg1video']:
                            cmd[i + 1] = 'mpeg2video'
        
        cmd.append(job.output_file)
        return cmd
    
    def execute_ffmpeg(self, cmd: list[str], output_file: str) -> tuple[bool, str]:
        """Execute the FFmpeg command."""
        try:
            startupinfo = None
            creationflags = 0
            if sys.platform == 'win32':
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE
                creationflags = subprocess.CREATE_NO_WINDOW
            
            # Run FFmpeg with Popen so we can terminate it
            self.current_process = subprocess.Popen(
                cmd, 
                stdout=subprocess.PIPE, 
                stderr=subprocess.PIPE,
                startupinfo=startupinfo,
                creationflags=creationflags,
                text=True
            )
            
            # Wait for process to complete or be cancelled
            stdout, stderr = self.current_process.communicate(timeout=3600)
            returncode = self.current_process.returncode
            self.current_process = None
            
            if self.is_cancelled:
                return False, "Cancelled by user"
            
            if returncode == 0:
                return True, "Success"
            else:
                error_msg = stderr[-500:] if stderr else "Unknown error"
                return False, f"FFmpeg error: {error_msg}"
        except subprocess.TimeoutExpired:
            if self.current_process:
                self.current_process.kill()
                self.current_process = None
            return False, "Encoding timed out (over 1 hour)"
        except FileNotFoundError:
            return False, "FFmpeg not found. Please install FFmpeg and add it to PATH."
        except Exception as e:
            if self.current_process:
                self.current_process.kill()
                self.current_process = None
            return False, str(e)
    
    def cancel(self):
        self.is_cancelled = True
        # Kill the current FFmpeg process if running
        if self.current_process:
            try:
                self.current_process.kill()
                self.current_process = None
            except:
                pass

# =============================================================================
# Main Window
# =============================================================================
class EncoderWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.encoding_thread: Optional[EncodingThread] = None
        self.jobs: list[EncodingJob] = []
        self.init_ui()
    
    def init_ui(self):
        self.setWindowTitle(APP_NAME)
        self.setMinimumSize(950, 750)
        self.resize(1100, 850)
        
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        
        # Header
        header_layout = QHBoxLayout()
        title_label = QLabel(APP_NAME)
        title_label.setFont(QFont("Courier", 18, QFont.Weight.Bold))
        header_layout.addWidget(title_label)
        header_layout.addStretch()
        main_layout.addLayout(header_layout)
        
        # File list section
        file_group = QGroupBox("Input Files")
        file_layout = QVBoxLayout()
        
        self.file_list = QListWidget()
        self.file_list.setMinimumHeight(120)
        self.file_list.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        file_layout.addWidget(self.file_list)
        
        file_btn_layout = QHBoxLayout()
        add_files_btn = QPushButton("Add Files")
        add_files_btn.clicked.connect(self.add_files)
        file_btn_layout.addWidget(add_files_btn)
        
        remove_files_btn = QPushButton("Remove Selected")
        remove_files_btn.clicked.connect(self.remove_files)
        file_btn_layout.addWidget(remove_files_btn)
        
        clear_files_btn = QPushButton("Clear All")
        clear_files_btn.clicked.connect(self.clear_files)
        file_btn_layout.addWidget(clear_files_btn)
        file_btn_layout.addStretch()
        
        file_layout.addLayout(file_btn_layout)
        file_group.setLayout(file_layout)
        main_layout.addWidget(file_group)
        
        # Encoding settings with scroll area
        settings_scroll = QScrollArea()
        settings_scroll.setWidgetResizable(True)
        settings_scroll.setMinimumHeight(330)
        settings_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        
        settings_widget = QWidget()
        settings_layout = QVBoxLayout(settings_widget)
        
        # Format selection
        format_layout = QHBoxLayout()
        format_layout.addWidget(QLabel("Output Format:"))
        self.format_combo = QComboBox()
        self.format_combo.addItems(['mp3', 'wav', 'flac', 'aiff', 'aac', 'm4a', 'ogg', 
                                    'mp4', 'mkv', 'avi', 'mov', 'webm', 'flv', 'wmv', 
                                    'mpeg', 'mpg', 'm4v', '3gp'])
        self.format_combo.currentTextChanged.connect(self.update_codec_options)
        format_layout.addWidget(self.format_combo)
        format_layout.addStretch()
        settings_layout.addLayout(format_layout)
        
        # Audio only checkbox
        self.audio_only_check = QCheckBox("Audio Only (Extract/Convert)")
        self.audio_only_check.stateChanged.connect(self.update_codec_options)
        settings_layout.addWidget(self.audio_only_check)
        
        # Audio settings group
        audio_group = QGroupBox("Audio Settings")
        audio_layout = QVBoxLayout()
        
        # Audio codec
        audio_codec_layout = QHBoxLayout()
        audio_codec_layout.addWidget(QLabel("Audio Codec:"))
        self.audio_codec_combo = QComboBox()
        self.audio_codec_combo.addItems(['aac', 'mp3', 'mp2', 'libvorbis', 'libopus', 'flac', 
                                         'pcm_s16le', 'pcm_s24le', 'pcm_s32le', 'pcm_f32le'])
        self.audio_codec_combo.currentTextChanged.connect(self.update_bit_depth_options)
        audio_codec_layout.addWidget(self.audio_codec_combo)
        audio_codec_layout.addStretch()
        audio_layout.addLayout(audio_codec_layout)
        
        # Bit depth and sample rate
        depth_rate_layout = QHBoxLayout()
        depth_rate_layout.addWidget(QLabel("Bit Depth:"))
        self.bit_depth_combo = QComboBox()
        self.bit_depth_combo.addItems(['8', '16', '24', '32', '32f'])
        self.bit_depth_combo.setCurrentText('16')
        depth_rate_layout.addWidget(self.bit_depth_combo)
        
        depth_rate_layout.addWidget(QLabel("Sample Rate:"))
        self.sample_rate_combo = QComboBox()
        self.sample_rate_combo.addItems(['22050', '44100', '48000', '96000', '192000'])
        self.sample_rate_combo.setCurrentText('44100')
        depth_rate_layout.addWidget(self.sample_rate_combo)
        depth_rate_layout.addStretch()
        audio_layout.addLayout(depth_rate_layout)
        
        # Audio bitrate
        audio_bitrate_layout = QHBoxLayout()
        audio_bitrate_layout.addWidget(QLabel("Audio Bitrate:"))
        self.audio_bitrate_spin = QSpinBox()
        self.audio_bitrate_spin.setRange(64, 320)
        self.audio_bitrate_spin.setValue(192)
        self.audio_bitrate_spin.setSuffix(" kbps")
        audio_bitrate_layout.addWidget(self.audio_bitrate_spin)
        audio_bitrate_layout.addStretch()
        audio_layout.addLayout(audio_bitrate_layout)
        
        audio_group.setLayout(audio_layout)
        settings_layout.addWidget(audio_group)
        
        # Video settings group
        self.video_group = QGroupBox("Video Settings")
        video_layout = QVBoxLayout()
        
        # Video codec
        video_codec_layout = QHBoxLayout()
        video_codec_layout.addWidget(QLabel("Video Codec:"))
        self.video_codec_combo = QComboBox()
        self.video_codec_combo.addItems(['libx264', 'libx265', 'libvpx-vp9', 'mpeg4', 
                                         'mpeg2video', 'libxvid', 'libx264rgb', 'copy'])
        video_codec_layout.addWidget(self.video_codec_combo)
        video_codec_layout.addStretch()
        video_layout.addLayout(video_codec_layout)
        
        # Video bitrate
        video_bitrate_layout = QHBoxLayout()
        video_bitrate_layout.addWidget(QLabel("Video Bitrate:"))
        self.video_bitrate_spin = QSpinBox()
        self.video_bitrate_spin.setRange(500, 50000)
        self.video_bitrate_spin.setValue(2000)
        self.video_bitrate_spin.setSuffix(" kbps")
        video_bitrate_layout.addWidget(self.video_bitrate_spin)
        video_bitrate_layout.addStretch()
        video_layout.addLayout(video_bitrate_layout)
        
        # Video dimensions
        dimensions_layout = QHBoxLayout()
        dimensions_layout.addWidget(QLabel("Width:"))
        self.width_spin = QSpinBox()
        self.width_spin.setRange(0, 7680)
        self.width_spin.setValue(0)
        self.width_spin.setSpecialValueText("Original")
        dimensions_layout.addWidget(self.width_spin)
        
        dimensions_layout.addWidget(QLabel("Height:"))
        self.height_spin = QSpinBox()
        self.height_spin.setRange(0, 4320)
        self.height_spin.setValue(0)
        self.height_spin.setSpecialValueText("Original")
        dimensions_layout.addWidget(self.height_spin)
        
        # Common presets
        preset_btn = QPushButton("720p")
        preset_btn.clicked.connect(lambda: self.set_dimensions(1280, 720))
        dimensions_layout.addWidget(preset_btn)
        
        preset_btn = QPushButton("1080p")
        preset_btn.clicked.connect(lambda: self.set_dimensions(1920, 1080))
        dimensions_layout.addWidget(preset_btn)
        
        preset_btn = QPushButton("4K")
        preset_btn.clicked.connect(lambda: self.set_dimensions(3840, 2160))
        dimensions_layout.addWidget(preset_btn)
        
        dimensions_layout.addStretch()
        video_layout.addLayout(dimensions_layout)
        
        # Frame rate
        fps_layout = QHBoxLayout()
        fps_layout.addWidget(QLabel("Frame Rate:"))
        self.fps_combo = QComboBox()
        self.fps_combo.addItems(['Original', '23.976', '24', '25', '29.97', '30', '50', '60'])
        fps_layout.addWidget(self.fps_combo)
        fps_layout.addStretch()
        video_layout.addLayout(fps_layout)
        
        self.video_group.setLayout(video_layout)
        settings_layout.addWidget(self.video_group)
        
        settings_scroll.setWidget(settings_widget)
        main_layout.addWidget(settings_scroll)
        
        # Output directory
        output_layout = QHBoxLayout()
        output_layout.addWidget(QLabel("Output Directory:"))
        self.output_dir_label = QLabel("(Same as input)")
        output_layout.addWidget(self.output_dir_label, 1)
        output_dir_btn = QPushButton("Browse...")
        output_dir_btn.clicked.connect(self.select_output_dir)
        output_layout.addWidget(output_dir_btn)
        main_layout.addLayout(output_layout)
        
        # Encode button
        encode_btn_layout = QHBoxLayout()
        self.encode_btn = QPushButton("Start Encoding")
        self.encode_btn.setMinimumHeight(40)
        self.encode_btn.clicked.connect(self.start_encoding)
        encode_btn_layout.addWidget(self.encode_btn)
        
        self.cancel_btn = QPushButton("Cancel")
        self.cancel_btn.setMinimumHeight(40)
        self.cancel_btn.setEnabled(False)
        self.cancel_btn.clicked.connect(self.cancel_encoding)
        encode_btn_layout.addWidget(self.cancel_btn)
        
        main_layout.addLayout(encode_btn_layout)
        
        # Progress
        progress_group = QGroupBox("Progress")
        progress_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        progress_layout.addWidget(self.progress_bar)
        
        self.status_label = QLabel("Ready")
        progress_layout.addWidget(self.status_label)
        
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setMaximumHeight(100)
        self.log_text.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        progress_layout.addWidget(self.log_text)
        
        progress_group.setLayout(progress_layout)
        main_layout.addWidget(progress_group)
        
        self.output_dir = None
        self.update_codec_options()
        self.update_bit_depth_options()
    
    def set_dimensions(self, width: int, height: int):
        """Set video dimensions to preset values."""
        self.width_spin.setValue(width)
        self.height_spin.setValue(height)
    
    def update_codec_options(self):
        """Update codec options based on format and audio-only setting."""
        audio_only = self.audio_only_check.isChecked()
        self.video_group.setVisible(not audio_only)
        
        # Auto-select appropriate codec for format
        fmt = self.format_combo.currentText()
        if fmt in ['wav', 'aiff']:
            self.audio_codec_combo.setCurrentText('pcm_s16le')
        elif fmt == 'flac':
            self.audio_codec_combo.setCurrentText('flac')
        elif fmt == 'mp3':
            self.audio_codec_combo.setCurrentText('mp3')
            self.audio_only_check.setChecked(True)
        elif fmt in ['aac', 'm4a']:
            self.audio_codec_combo.setCurrentText('aac')
        elif fmt == 'ogg':
            self.audio_codec_combo.setCurrentText('libvorbis')
        elif fmt == 'webm':
            self.audio_codec_combo.setCurrentText('libvorbis')
            self.video_codec_combo.setCurrentText('libvpx-vp9')
        elif fmt in ['mpeg', 'mpg']:
            self.audio_codec_combo.setCurrentText('mp2')
            self.video_codec_combo.setCurrentText('mpeg2video')
        elif fmt in ['mov', 'mp4', 'm4v']:
            self.audio_codec_combo.setCurrentText('aac')
            self.video_codec_combo.setCurrentText('libx264')
    
    def update_bit_depth_options(self):
        """Enable/disable bit depth based on codec."""
        codec = self.audio_codec_combo.currentText()
        is_pcm = codec.startswith('pcm_')
        self.bit_depth_combo.setEnabled(is_pcm or codec == 'flac')
    
    def add_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, "Select Media Files", "",
            "Media Files (*.mp4 *.mkv *.avi *.mov *.flv *.wmv *.mpeg *.mpg *.m4v *.3gp *.mp3 *.wav *.flac *.aac *.m4a *.ogg *.aiff *.aif);;All Files (*.*)"
        )
        for file in files:
            self.file_list.addItem(file)
    
    def remove_files(self):
        for item in self.file_list.selectedItems():
            self.file_list.takeItem(self.file_list.row(item))
    
    def clear_files(self):
        self.file_list.clear()
    
    def select_output_dir(self):
        directory = QFileDialog.getExistingDirectory(self, "Select Output Directory")
        if directory:
            self.output_dir = directory
            self.output_dir_label.setText(directory)
    
    def start_encoding(self):
        if self.file_list.count() == 0:
            QMessageBox.warning(self, "No Files", "Please add files to encode.")
            return
        
        # Build jobs
        self.jobs = []
        for i in range(self.file_list.count()):
            input_file = self.file_list.item(i).text()
            input_path = Path(input_file)
            
            if self.output_dir:
                output_path = Path(self.output_dir) / f"{input_path.stem}_encoded.{self.format_combo.currentText()}"
            else:
                output_path = input_path.parent / f"{input_path.stem}_encoded.{self.format_combo.currentText()}"
            
            fps = None if self.fps_combo.currentText() == 'Original' else self.fps_combo.currentText()
            width = self.width_spin.value() if self.width_spin.value() > 0 else None
            height = self.height_spin.value() if self.height_spin.value() > 0 else None
            
            job = EncodingJob(
                input_file=input_file,
                output_file=str(output_path),
                format=self.format_combo.currentText(),
                audio_codec=self.audio_codec_combo.currentText(),
                video_codec=self.video_codec_combo.currentText() if not self.audio_only_check.isChecked() else None,
                audio_bitrate=f"{self.audio_bitrate_spin.value()}k",
                sample_rate=self.sample_rate_combo.currentText(),
                bit_depth=self.bit_depth_combo.currentText(),
                video_bitrate=f"{self.video_bitrate_spin.value()}k" if not self.audio_only_check.isChecked() else None,
                video_width=width,
                video_height=height,
                video_fps=fps,
                audio_only=self.audio_only_check.isChecked()
            )
            self.jobs.append(job)
        
        # Start encoding
        self.progress_bar.setMaximum(len(self.jobs))
        self.progress_bar.setValue(0)
        self.log_text.clear()
        self.encode_btn.setEnabled(False)
        self.cancel_btn.setEnabled(True)
        self.log_text.append(f"Starting batch encode of {len(self.jobs)} file(s)...")
        self.log_text.append("Note: VP9/WebM encoding can be slow. Please be patient.")
        
        self.encoding_thread = EncodingThread(self.jobs)
        self.encoding_thread.job_started.connect(self.on_job_started)
        self.encoding_thread.job_complete.connect(self.on_job_complete)
        self.encoding_thread.all_complete.connect(self.on_all_complete)
        self.encoding_thread.finished.connect(self.on_encoding_finished)
        self.encoding_thread.start()
    
    def cancel_encoding(self):
        if self.encoding_thread and self.encoding_thread.isRunning():
            self.log_text.append("Cancelling encoding...")
            self.encoding_thread.cancel()
            self.cancel_btn.setEnabled(False)
    
    def on_job_started(self, current: int, total: int, filename: str, ffmpeg_cmd: str):
        # Set progress bar to busy/indeterminate mode
        self.progress_bar.setMaximum(0)
        self.progress_bar.setMinimum(0)
        self.status_label.setText(f"Encoding file {current}/{total}: {filename}")
        self.log_text.append(f"--- Starting file {current}/{total}: {filename} ---")
        self.log_text.append(f"Command: {ffmpeg_cmd}")
        QApplication.processEvents()
    
    def on_job_complete(self, output_file: str, success: bool, message: str, completed: int):
        status = "✓" if success else "✗"
        self.log_text.append(f"{status} {Path(output_file).name}: {message}")
        self.log_text.append(f"Completed {completed}/{len(self.jobs)} files")
        # Reset progress bar to show completion count
        self.progress_bar.setMaximum(len(self.jobs))
        self.progress_bar.setValue(completed)
        QApplication.processEvents()
    
    def on_all_complete(self):
        self.progress_bar.setMaximum(len(self.jobs))
        self.progress_bar.setValue(len(self.jobs))
    
    def on_encoding_finished(self):
        self.encode_btn.setEnabled(True)
        self.cancel_btn.setEnabled(False)
        self.status_label.setText("Encoding complete!")
        QMessageBox.information(self, "Complete", "All encoding jobs finished!")

# =============================================================================
# Main Entry Point
# =============================================================================
def main():
    import time
    
    app = QApplication(sys.argv)
    app.setOrganizationName(ORG_NAME)
    app.setApplicationName(APP_NAME)
    
    # Show splash screen
    splash = create_splash()
    if splash:
        splash.show()
        splash.showMessage("\n\n\n\n\n\n\nInitializing...", 
                          Qt.AlignmentFlag.AlignBottom | Qt.AlignmentFlag.AlignCenter, 
                          QColor(255, 255, 255))
        app.processEvents()
        
        # Display splash for exactly 5.4 seconds
        start_time = time.time()
        while time.time() - start_time < 5.4:
            app.processEvents()
            time.sleep(0.05)
    
    # Create main window
    window = EncoderWindow()
    
    if splash:
        splash.finish(window)
    
    window.show()
    sys.exit(app.exec())

if __name__ == '__main__':
    main()